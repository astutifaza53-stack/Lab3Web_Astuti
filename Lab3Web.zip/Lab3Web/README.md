# Lab3Web - Praktikum 3: CSS Dasar

Mata Kuliah: Pemrograman Web
Nama: Astuti  
NIM: 312510320  
Kelas: I252A

## Struktur File

| File | Keterangan |
|---|---|
| `lab2_css_dasar.html` | Dokumen utama praktikum (HTML + CSS internal + inline) |
| `style_eksternal.css` | CSS eksternal, selector ID/Class, dan eksperimen Tugas 1 |
| `tugas3_prioritas_css.html` + `demo_eksternal.css` | Demo jawaban Tugas 3 |
| `tugas4_id_vs_class.html` | Demo jawaban Tugas 4 |
| `screenshots/` | Folder screenshot (simpan hasil di sini) |

---

## Langkah Praktikum

### 1. Membuat Dokumen HTML
Dibuat file `lab2_css_dasar.html` berisi struktur dasar HTML: `header` (h1), `nav` (3 link), dan `div#intro` (h1, paragraf, dan link bergaya tombol). Tanpa CSS, tampilan masih standar browser.

![Langkah 1](screenshots/01_html_dasar.png)

### 2. Mendeklarasikan CSS Internal
Ditambahkan tag `<style>` di dalam `<head>` untuk mengatur font `body`, tinggi dan garis bawah `header`, serta ukuran, warna, perataan, dan padding `h1`. Selector `h1 i` mewarnai teks miring menjadi abu-abu.

![Langkah 2](screenshots/02_css_internal.png)

### 3. Menambahkan Inline CSS
Atribut `style="text-align: center; color: #ccd8e4;"` ditambahkan pada tag `<p>`. Inline CSS hanya memengaruhi satu elemen tersebut.

![Langkah 3](screenshots/03_inline_css.png)

### 4. Membuat CSS Eksternal
Dibuat file `style_eksternal.css` berisi gaya `nav`, `nav a`, serta `nav .active` dan `nav a:hover`. File dihubungkan lewat `<link rel="stylesheet" href="style_eksternal.css">` di `<head>`. Menu navigasi menjadi hijau.

![Langkah 4](screenshots/04_css_eksternal.png)

### 5. Menambahkan CSS Selector
Pada `style_eksternal.css` ditambahkan:
- **ID selector** `#intro` dan `#intro h1` untuk kotak biru dan judul putih rata kiri.
- **Class selector** `.button` dan `.btn-primary` untuk link yang tampil seperti tombol merah.

![Langkah 5](screenshots/05_selector.png)

### 6. Validasi CSS
File CSS divalidasi melalui https://jigsaw.w3.org/css-validator/

![Validasi](screenshots/06_validasi.png)

---

## Pertanyaan dan Tugas

### 1. Eksperimen properti CSS
Properti yang dicoba (ada di bagian akhir `style_eksternal.css`):

| Elemen | Properti | Efek |
|---|---|---|
| `header` | `background`, `box-shadow` | Latar muda dan bayangan tipis |
| `p` | `line-height`, `font-size` | Teks lebih renggang dan mudah dibaca |
| `.button` | `border-radius`, `font-weight` | Tombol membulat dan huruf tebal |
| `.btn-primary:hover` | `background` | Warna tombol menggelap saat kursor di atasnya |
| `nav a` | `font-size`, `letter-spacing` | Menu lebih besar dan berjarak |

![Eksperimen](screenshots/07_eksperimen.png)

### 2. Perbedaan `h1 {...}` dan `#intro h1 {...}`

| | `h1 {...}` | `#intro h1 {...}` |
|---|---|---|
| Jenis | Element selector | Descendant selector (ID + elemen) |
| Cakupan | Semua `<h1>` di halaman | Hanya `<h1>` di dalam elemen `id="intro"` |
| Spesifisitas | Rendah (0,0,1) | Lebih tinggi (1,0,1) |

Pada praktikum ini terdapat dua `<h1>`: di `<header>` dan di `<div id="intro">`. Aturan `h1` mengenai keduanya (biru, rata tengah). Aturan `#intro h1` hanya mengenai "Hello World" dan menimpa aturan `h1` karena spesifisitasnya lebih tinggi, sehingga judul menjadi putih dan rata kiri.

### 3. Prioritas CSS internal, eksternal, dan inline
**Yang tampil adalah Inline CSS**, karena inline memiliki prioritas tertinggi dalam cascade (selain `!important`). Internal dan eksternal setara, sehingga yang ditulis **paling akhir** dalam dokumen yang menang (jika spesifisitas sama).

Contoh (lihat `tugas3_prioritas_css.html`):
- Eksternal: `p { color: red; }`
- Internal (setelah `<link>`): `p { color: blue; }`
- Inline: `<p style="color: green;">`

Hasil: paragraf dengan inline berwarna **hijau**. Paragraf tanpa inline berwarna **biru**. Jika `<style>` diletakkan sebelum `<link>`, hasilnya menjadi **merah**.

![Tugas 3](screenshots/08_tugas3.png)

### 4. Prioritas ID dan Class pada satu elemen
Untuk `<p id="paragraf-1" class="textparagraf">`, **deklarasi ID yang tampil** karena spesifisitas ID (1,0,0) lebih tinggi dari class (0,1,0), apa pun urutan penulisannya.

Contoh (lihat `tugas4_id_vs_class.html`):
```css
#paragraf-1   { color: red; }
.textparagraf { color: blue; font-size: 20px; }
```
Hasil: teks **merah** (dari ID), tetapi `font-size: 20px` tetap berlaku karena tidak bentrok.

Urutan prioritas: inline > ID > class > elemen.

![Tugas 4](screenshots/09_tugas4.png)
